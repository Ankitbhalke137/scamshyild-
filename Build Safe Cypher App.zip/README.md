
  # Build Safe Cypher App

  This is a code bundle for Build Safe Cypher App. The original project is available at https://www.figma.com/design/meMIDLeVNMn91jddsyaPCx/Build-Safe-Cypher-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  